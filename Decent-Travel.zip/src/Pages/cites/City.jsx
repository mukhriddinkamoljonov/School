import React from 'react'

const City = () => {
  return (
    <div>CIty</div>
  )
}

export default City